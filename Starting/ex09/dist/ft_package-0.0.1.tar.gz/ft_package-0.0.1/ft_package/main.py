def say_hello():
    print("Hello from ft_package!")
